
// var i = 1;
// if (i<=10) {
// 	$('.workImgContainer').addClass(".applyImg");
// 	};



$(document).ready(function(){
	window.onload = function(){
	  
	  $("header nav ul li:first-child").click(function(){
	  	console.log('worked');
	    $('html,body').animate({scrollTop:0}, 500);
	  });

	  $("header nav ul li:nth-child(2)").click(function(){
	    $('html,body').animate({scrollTop:$('#myThinking').offset().top}, 500);
	  });

	  $("header nav ul li:nth-child(3)").click(function(){
	    $('html,body').animate({scrollTop:$('#myBlog').offset().top}, 500);
	  });	

	};
});



// $(".navLink").click(function(){
// 	console.log('worked');
// 	$('html,body').animate({scrollTop:0}, 1000);
// });

// $('nav ul li:nth-child(2)').click(function(){
// 	$('html,body').animate({
// 		scrollTop: ($('#myThinking')}, 1000);
// });

// $('nav ul li:nth-child(3)').click(function(){
// 	console.log('worked');
// 	$('html,body').animate({
// 		scrollTop: ($('#myBlog')}, 1000);
// });

// $('#myThinking').click(function(){
// 	$('html,body').animate({scrollTop:500},1000);
// 	return false;
// });